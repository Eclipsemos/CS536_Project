public class SymDuplicationException extends Exception {
	
}