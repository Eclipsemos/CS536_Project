public class SymTabEmptyException extends Exception {
	
}